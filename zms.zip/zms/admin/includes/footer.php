<footer>
            <div class="footer-area">
                <p>Zoo Management System </p>
            </div>
        </footer>