   <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <p style="color: white">ZMS ADMIN</p>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="dashboard.php" aria-expanded="true"><i class="ti-dashboard"></i><span>Dashboard</span></a>
                               
                            </li>
                             <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Animals Details</span></a>
                                <ul class="collapse">
                                    <li><a href="add-animals.php">Add Animals</a></li>
                                    <li><a href="manage-animals.php">Manage Animals</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Ticket</span></a>
                                <ul class="collapse">
                                    <li><a href="add-normal-ticket.php">Add Ticket</a></li>
                                    <li><a href="manage-normal-ticket.php">Manage Ticket</a></li>
                                </ul>
                            </li>
                             <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Doctors details</span></a>
                                <ul class="collapse">
                                    <li><a href="add-health.php">Add healthcaretakers</a></li>
                                    <li><a href="manage-health.php">Manage healthcaretakers</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-search"></i><span>Search</span></a>
                                <ul class="collapse">
                                    <li><a href="normal-search.php">Ticket Search</a></li>
                                    <li><a href="employee-search.php">Employee Search</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Reports</span></a>
                                <ul class="collapse">
                                    <li><a href="between-date.php">People Report</a></li>
                                    <li><a href="no-child.php">People with no child</a></li>
                                    <li><a href="dr-only.php">Dr. in healthcaretakers</a></li>
                                </ul>
                            </li>
                            
                           
                        </ul>
                    </nav>
                </div>
            </div>
        </div>